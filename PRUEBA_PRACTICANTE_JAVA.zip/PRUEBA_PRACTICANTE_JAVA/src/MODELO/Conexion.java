package MODELO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    Connection conex;
    String URL = "jdbc:mysql://localhost:3307/PRUEBA_PRACTICANTE_JAVA?serverTimezone=UTC";
    String USUARIO = "root";
    String PASSAWORD = "12345678";

    public Conexion() {

        try {
            conex = DriverManager.getConnection(URL, USUARIO, PASSAWORD);

        } catch (SQLException ex) {
            System.err.print("Erorr " + ex);
        }
    }

    public Connection getConexion() {
        return conex;
    }
}