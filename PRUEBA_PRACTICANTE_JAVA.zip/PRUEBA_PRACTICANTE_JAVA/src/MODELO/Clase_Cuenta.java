
package MODELO;

public class Clase_Cuenta {
    
   private double SALDO_CUENTA ;
   private String TITULAR_CUENTA;

    public Clase_Cuenta(double SALDO_CUENTA, String TITULAR_CUENTA) {
        this.SALDO_CUENTA = SALDO_CUENTA;
        this.TITULAR_CUENTA = TITULAR_CUENTA;
    }

    public double getSALDO_CUENTA() {
        return SALDO_CUENTA;
    }

    public void setSALDO_CUENTA(double SALDO_CUENTA) {
        this.SALDO_CUENTA = SALDO_CUENTA;
    }

    public String getTITULAR_CUENTA() {
        return TITULAR_CUENTA;
    }

    public void setTITULAR_CUENTA(String TITULAR_CUENTA) {
        this.TITULAR_CUENTA = TITULAR_CUENTA;
    }

 
    
}
