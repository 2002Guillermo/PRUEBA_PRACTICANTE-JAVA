package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import javax.swing.JOptionPane;

public class Modelo_Historial_transaciones {
    
    Conexion con;
    Connection C;
    
    public Modelo_Historial_transaciones() {
        con = new Conexion();
        C = con.getConexion();
        
    }
    
    public LinkedList Historial_Transaciones_Cuenta(int NUMERO_CUENTA_FK) {
        LinkedList<Clase_Transacion> Lista = new LinkedList();
        try {
            String buscar = "SELECT * FROM TRANSACIONES WHERE NUMERO_CUENTA_FK= ?";
            PreparedStatement s = C.prepareStatement(buscar);
            s.setInt(1, NUMERO_CUENTA_FK);
            ResultSet rs = s.executeQuery();
            while (rs.next()) {
                Lista.add(new Clase_Transacion(rs.getInt("NUMERO_CUENTA_FK"),
                        rs.getString("TIPO_TRANSACION"), rs.getDouble("VALOR_TRANSACION"),
                        rs.getString("FECHA_TRANSACION")
                ));
            }
        } catch (SQLException ex) {
            System.err.println("Error: " + ex);
        }
        return Lista;
    }
}
